using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Pizzas.API.Models;
using Pizzas.API.Utils;

namespace Pizzas.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PizzaController : ControllerBase
    {
        [HttpGet]

        public IActionResult getAll()
        {
            IActionResult respuesta;
            List<Pizza> entityList;
            entityList = BD.GetAll();
            respuesta = Ok(entityList);
            return (respuesta);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            IActionResult respuesta;
            Pizza unaPizza =  BD.GetById(id);
            if(unaPizza == null){
                respuesta = NotFound();
            }
            else{
                respuesta = Ok(unaPizza);
            }
            
            return (respuesta);
        }
        [HttpPost]
        public IActionResult Create(Pizza pizza)
        {
            int intRowsAffected;
            intRowsAffected = BD.Insert(pizza);
            return CreatedAtAction(nameof(Create), new{id= pizza.Id},pizza);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, Pizza pizza)
        {
            int intRowsAffected = 0;
            Pizza entity ;
            IActionResult   respuesta = null;
            if(id!= pizza.Id ){
                return BadRequest();
            }else{
                entity = BD.GetById(id);
                if(entity == null){
                    return NotFound();
                }else{
                    intRowsAffected=BD.UpdateById(pizza);
                    if(intRowsAffected > 0){
                        respuesta = Ok(pizza);
                    }
                    else{
                        respuesta = NotFound();
                    }
                }
                
            }
            return respuesta;
        }


        [HttpDelete("{id}")]
        public IActionResult DeleteByID(int id)
        {
            IActionResult   respuesta = null;
            int intRowsAffected = 0;
            Pizza entity;
            entity = BD.GetById(id);
            if(id < 0 ){
                respuesta = BadRequest();
            }else{
                if (entity == null){
                    respuesta = NotFound();
                }else{
                    intRowsAffected = BD.DeleteById(id);
                    if(intRowsAffected > 0){
                        respuesta = Ok(entity);
                    }else{
                        respuesta=NotFound();
                    }
                }
                
            }
            return respuesta;
        }


    }


}
