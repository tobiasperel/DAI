using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using Dapper;
using Usuarios.API.Models;

namespace Usuarios.API.Utils
{
    public static class UsuariosServices
    {
        public static Usuario Login(string userName, string password)
        {
            Usuario usuario = null;
            using (SqlConnection db = new SqlConnection(_connectionString))
            {
                string sql = "SELECT * FROM USUARIOS WHERE UserName = @pUserName & Password = @pPassword ";
                usuario = db.QueryFirstOrDefault<Pizza>(sql, new { pUserName = userName, pPassword = password});
            }
            return usuario;
        }

    }
}